
public class MainClass {

	public static void main(String[] args) {
		Board gameBoard = new Board();
		
		gameBoard.create();
		gameBoard.run();

	}

}
